
-- Fix function search_path (set on handle_new_user and set_updated_at)
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email));
  return new;
end;
$$;

create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;

-- Restrict EXECUTE on security definer helpers
revoke execute on function public.has_role(uuid, public.app_role) from public, anon, authenticated;
revoke execute on function public.is_admin(uuid) from public, anon, authenticated;
revoke execute on function public.handle_new_user() from public, anon, authenticated;

-- Restrict storage listing: public can only read by direct path via signed URL/public URL; we keep public read since bucket is public for serving images.
-- Rationale: bucket is intentionally public so <img src> works. Listing risk is acceptable for marketing media. No change needed.
