
-- Enum role
create type public.app_role as enum ('admin', 'user');

-- Profiles
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

-- User roles
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.is_admin(_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = 'admin')
$$;

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email));
  return new;
end;
$$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- updated_at helper
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

-- Site settings (singleton row id=1)
create table public.site_settings (
  id int primary key default 1,
  school_name text not null default 'SMA Nusantara',
  tagline text not null default 'Membentuk Generasi Cerdas, Berkarakter, dan Berprestasi',
  logo_url text,
  hero_image_url text,
  hero_title text default 'Selamat Datang di SMA Nusantara',
  hero_subtitle text default 'Sekolah unggulan untuk masa depan gemilang',
  description text default 'SMA Nusantara adalah sekolah menengah atas yang berkomitmen pada kualitas pendidikan, karakter, dan inovasi.',
  vision text default 'Menjadi sekolah unggul yang menghasilkan lulusan berakhlak mulia, cerdas, dan kompetitif secara global.',
  mission text default '- Menyelenggarakan pembelajaran berkualitas\n- Mengembangkan potensi siswa secara holistik\n- Membangun karakter dan budi pekerti\n- Mendorong prestasi akademik dan non-akademik',
  stat_students int not null default 1200,
  stat_teachers int not null default 75,
  stat_achievements int not null default 230,
  stat_alumni int not null default 5400,
  ppdb_open boolean not null default true,
  ppdb_title text default 'PPDB Tahun Ajaran 2026/2027',
  ppdb_description text default 'Pendaftaran Peserta Didik Baru telah dibuka. Bergabunglah bersama kami!',
  ppdb_url text default '#',
  ppdb_deadline text default '30 Juni 2026',
  address text default 'Jl. Pendidikan No. 1, Jakarta',
  phone text default '+62 21 1234 5678',
  email text default 'info@smanusantara.sch.id',
  facebook_url text,
  instagram_url text,
  youtube_url text,
  maps_embed_url text default 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.1234!2d106.8!3d-6.2!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNsKwMTInMDAuMCJTIDEwNsKwNDgnMDAuMCJF!5e0!3m2!1sen!2sid!4v1700000000000',
  updated_at timestamptz not null default now()
);
alter table public.site_settings enable row level security;
insert into public.site_settings (id) values (1);
create trigger site_settings_updated before update on public.site_settings for each row execute function public.set_updated_at();

-- News
create table public.news (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  excerpt text,
  content text not null,
  image_url text,
  published boolean not null default false,
  published_at timestamptz default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.news enable row level security;
create trigger news_updated before update on public.news for each row execute function public.set_updated_at();
create index news_published_idx on public.news(published, published_at desc);

-- Gallery
create table public.gallery (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  caption text,
  image_url text not null,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);
alter table public.gallery enable row level security;

-- Teachers
create table public.teachers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  position text not null,
  subject text,
  photo_url text,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);
alter table public.teachers enable row level security;

-- Testimonials
create table public.testimonials (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  role text not null,
  content text not null,
  photo_url text,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);
alter table public.testimonials enable row level security;

-- RLS POLICIES
-- Profiles: owner read/update
create policy "profiles_self_select" on public.profiles for select using (auth.uid() = id);
create policy "profiles_self_update" on public.profiles for update using (auth.uid() = id);

-- user_roles: user can read own; admin can manage
create policy "roles_self_read" on public.user_roles for select using (auth.uid() = user_id or public.is_admin(auth.uid()));
create policy "roles_admin_all" on public.user_roles for all using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- site_settings: public read, admin write
create policy "settings_public_read" on public.site_settings for select using (true);
create policy "settings_admin_update" on public.site_settings for update using (public.is_admin(auth.uid()));

-- news: public read published, admin all
create policy "news_public_read" on public.news for select using (published = true or public.is_admin(auth.uid()));
create policy "news_admin_insert" on public.news for insert with check (public.is_admin(auth.uid()));
create policy "news_admin_update" on public.news for update using (public.is_admin(auth.uid()));
create policy "news_admin_delete" on public.news for delete using (public.is_admin(auth.uid()));

-- gallery
create policy "gallery_public_read" on public.gallery for select using (true);
create policy "gallery_admin_write" on public.gallery for all using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- teachers
create policy "teachers_public_read" on public.teachers for select using (true);
create policy "teachers_admin_write" on public.teachers for all using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- testimonials
create policy "testimonials_public_read" on public.testimonials for select using (true);
create policy "testimonials_admin_write" on public.testimonials for all using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- Storage bucket
insert into storage.buckets (id, name, public) values ('site-media', 'site-media', true);
create policy "site_media_public_read" on storage.objects for select using (bucket_id = 'site-media');
create policy "site_media_admin_insert" on storage.objects for insert with check (bucket_id = 'site-media' and public.is_admin(auth.uid()));
create policy "site_media_admin_update" on storage.objects for update using (bucket_id = 'site-media' and public.is_admin(auth.uid()));
create policy "site_media_admin_delete" on storage.objects for delete using (bucket_id = 'site-media' and public.is_admin(auth.uid()));

-- Seed data
insert into public.teachers (name, position, subject, sort_order) values
('Dr. Budi Santoso, M.Pd', 'Kepala Sekolah', 'Manajemen Pendidikan', 1),
('Siti Aminah, S.Pd', 'Wakil Kepala Sekolah', 'Bahasa Indonesia', 2),
('Agus Wijaya, S.Si', 'Guru', 'Matematika', 3),
('Dewi Lestari, S.Pd', 'Guru', 'Bahasa Inggris', 4),
('Rahmat Hidayat, M.Sc', 'Guru', 'Fisika', 5),
('Indah Permata, S.Pd', 'Guru', 'Biologi', 6);

insert into public.testimonials (name, role, content, sort_order) values
('Andi Pratama', 'Alumni 2023', 'SMA Nusantara memberikan saya bekal akademik dan karakter yang luar biasa untuk melanjutkan ke universitas impian.', 1),
('Putri Maharani', 'Siswa Kelas XII', 'Suasana belajar di sini sangat mendukung. Guru-gurunya inspiratif dan fasilitasnya lengkap.', 2),
('Bapak Hendra', 'Orang Tua Siswa', 'Saya sangat puas dengan pendidikan karakter yang diberikan sekolah ini kepada anak saya.', 3);

insert into public.news (title, slug, excerpt, content, published, published_at) values
('Juara Umum Olimpiade Sains Tingkat Provinsi', 'juara-osn-provinsi', 'Tim sains SMA Nusantara berhasil meraih juara umum dalam ajang OSN tingkat provinsi.', 'Prestasi membanggakan kembali diraih oleh siswa SMA Nusantara dalam Olimpiade Sains Nasional tingkat provinsi tahun ini. Tim yang terdiri dari 5 siswa terbaik berhasil mengalahkan ratusan peserta dari berbagai sekolah.', true, now() - interval '1 day'),
('Pembukaan PPDB Tahun Ajaran 2026/2027', 'pembukaan-ppdb-2026', 'Pendaftaran Peserta Didik Baru tahun ajaran 2026/2027 resmi dibuka.', 'Mulai hari ini, SMA Nusantara membuka pendaftaran peserta didik baru untuk tahun ajaran 2026/2027. Pendaftaran dapat dilakukan secara online maupun langsung ke sekolah.', true, now() - interval '3 days'),
('Workshop Kepemimpinan untuk OSIS', 'workshop-kepemimpinan-osis', 'Pengurus OSIS mengikuti workshop kepemimpinan selama 2 hari.', 'Untuk membekali pengurus OSIS dengan kemampuan kepemimpinan, sekolah mengadakan workshop intensif selama 2 hari di aula sekolah.', true, now() - interval '7 days'),
('Studi Banding ke Universitas Indonesia', 'studi-banding-ui', 'Siswa kelas XII melakukan studi banding ke UI untuk persiapan kuliah.', 'Sebanyak 120 siswa kelas XII mengikuti kegiatan studi banding ke Universitas Indonesia sebagai bentuk persiapan menuju jenjang perguruan tinggi.', true, now() - interval '10 days');
