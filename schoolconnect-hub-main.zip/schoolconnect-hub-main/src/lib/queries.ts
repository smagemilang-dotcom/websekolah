import { supabase } from "@/integrations/supabase/client";

export type SiteSettings = {
  id: number;
  school_name: string;
  tagline: string;
  logo_url: string | null;
  hero_image_url: string | null;
  hero_title: string | null;
  hero_subtitle: string | null;
  description: string | null;
  vision: string | null;
  mission: string | null;
  stat_students: number;
  stat_teachers: number;
  stat_achievements: number;
  stat_alumni: number;
  ppdb_open: boolean;
  ppdb_title: string | null;
  ppdb_description: string | null;
  ppdb_url: string | null;
  ppdb_deadline: string | null;
  address: string | null;
  phone: string | null;
  email: string | null;
  facebook_url: string | null;
  instagram_url: string | null;
  youtube_url: string | null;
  maps_embed_url: string | null;
};

export async function getSettings(): Promise<SiteSettings> {
  const { data, error } = await supabase.from("site_settings").select("*").eq("id", 1).single();
  if (error) throw error;
  return data as SiteSettings;
}

export async function getNews(opts: { limit?: number; published?: boolean; search?: string } = {}) {
  let q = supabase.from("news").select("*").order("published_at", { ascending: false });
  if (opts.published !== false) q = q.eq("published", true);
  if (opts.limit) q = q.limit(opts.limit);
  if (opts.search) q = q.ilike("title", `%${opts.search}%`);
  const { data, error } = await q;
  if (error) throw error;
  return data ?? [];
}

export async function getNewsBySlug(slug: string) {
  const { data, error } = await supabase.from("news").select("*").eq("slug", slug).maybeSingle();
  if (error) throw error;
  return data;
}

export async function getGallery() {
  const { data, error } = await supabase.from("gallery").select("*").order("sort_order");
  if (error) throw error;
  return data ?? [];
}

export async function getTeachers() {
  const { data, error } = await supabase.from("teachers").select("*").order("sort_order");
  if (error) throw error;
  return data ?? [];
}

export async function getTestimonials() {
  const { data, error } = await supabase.from("testimonials").select("*").order("sort_order");
  if (error) throw error;
  return data ?? [];
}
