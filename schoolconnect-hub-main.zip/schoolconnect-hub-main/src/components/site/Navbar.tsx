import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, X, GraduationCap } from "lucide-react";
import { cn } from "@/lib/utils";

const links = [
  { to: "/", label: "Beranda" },
  { to: "/profil", label: "Profil" },
  { to: "/berita", label: "Berita" },
  { to: "/galeri", label: "Galeri" },
  { to: "/guru", label: "Guru" },
  { to: "/ppdb", label: "PPDB" },
  { to: "/kontak", label: "Kontak" },
] as const;

export function Navbar({ schoolName = "SMA Nusantara", logoUrl }: { schoolName?: string; logoUrl?: string | null }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={cn("sticky top-0 z-50 w-full transition-smooth", scrolled ? "bg-background/85 backdrop-blur-lg border-b shadow-soft" : "bg-transparent")}>
      <nav className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2 font-bold">
          {logoUrl ? <img src={logoUrl} alt={schoolName} className="h-9 w-9 rounded-md object-cover" /> : <div className="flex h-9 w-9 items-center justify-center rounded-md bg-gradient-primary text-primary-foreground"><GraduationCap className="h-5 w-5" /></div>}
          <span className="text-lg">{schoolName}</span>
        </Link>
        <ul className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <li key={l.to}>
              <Link to={l.to} className="rounded-md px-3 py-2 text-sm font-medium text-foreground/80 transition-smooth hover:bg-secondary hover:text-primary" activeProps={{ className: "bg-secondary text-primary" }} activeOptions={{ exact: l.to === "/" }}>
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </nav>
      {open && (
        <div className="border-t bg-background md:hidden">
          <ul className="container mx-auto flex flex-col px-4 py-2">
            {links.map((l) => (
              <li key={l.to}>
                <Link to={l.to} onClick={() => setOpen(false)} className="block rounded-md px-3 py-2.5 text-sm font-medium hover:bg-secondary" activeProps={{ className: "bg-secondary text-primary" }} activeOptions={{ exact: l.to === "/" }}>
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </header>
  );
}
