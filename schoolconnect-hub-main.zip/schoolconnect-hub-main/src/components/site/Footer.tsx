import { MapPin, Phone, Mail, Facebook, Instagram, Youtube, GraduationCap } from "lucide-react";
import type { SiteSettings } from "@/lib/queries";

export function Footer({ s }: { s: SiteSettings }) {
  return (
    <footer className="bg-sidebar text-sidebar-foreground">
      <div className="container mx-auto grid gap-10 px-4 py-14 md:grid-cols-4">
        <div>
          <div className="mb-4 flex items-center gap-2 font-bold text-lg">
            {s.logo_url ? <img src={s.logo_url} alt="" className="h-9 w-9 rounded-md" /> : <div className="flex h-9 w-9 items-center justify-center rounded-md bg-gradient-primary"><GraduationCap className="h-5 w-5" /></div>}
            {s.school_name}
          </div>
          <p className="text-sm text-sidebar-foreground/70">{s.tagline}</p>
        </div>
        <div>
          <h4 className="mb-3 font-semibold">Kontak</h4>
          <ul className="space-y-2 text-sm text-sidebar-foreground/80">
            <li className="flex gap-2"><MapPin className="h-4 w-4 mt-0.5 shrink-0" />{s.address}</li>
            <li className="flex gap-2"><Phone className="h-4 w-4 mt-0.5 shrink-0" />{s.phone}</li>
            <li className="flex gap-2"><Mail className="h-4 w-4 mt-0.5 shrink-0" />{s.email}</li>
          </ul>
        </div>
        <div>
          <h4 className="mb-3 font-semibold">Sosial Media</h4>
          <div className="flex gap-3">
            {s.facebook_url && <a href={s.facebook_url} target="_blank" rel="noreferrer" className="rounded-md bg-sidebar-accent p-2 hover:bg-primary"><Facebook className="h-4 w-4" /></a>}
            {s.instagram_url && <a href={s.instagram_url} target="_blank" rel="noreferrer" className="rounded-md bg-sidebar-accent p-2 hover:bg-primary"><Instagram className="h-4 w-4" /></a>}
            {s.youtube_url && <a href={s.youtube_url} target="_blank" rel="noreferrer" className="rounded-md bg-sidebar-accent p-2 hover:bg-primary"><Youtube className="h-4 w-4" /></a>}
          </div>
        </div>
        <div>
          <h4 className="mb-3 font-semibold">Lokasi</h4>
          {s.maps_embed_url && (
            <div className="overflow-hidden rounded-md border border-sidebar-border">
              <iframe src={s.maps_embed_url} loading="lazy" className="h-32 w-full" title="Lokasi sekolah" />
            </div>
          )}
        </div>
      </div>
      <div className="border-t border-sidebar-border py-4 text-center text-xs text-sidebar-foreground/60">
        © {new Date().getFullYear()} {s.school_name}. Hak cipta dilindungi.
      </div>
    </footer>
  );
}
