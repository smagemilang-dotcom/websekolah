import { useEffect, useState } from "react";
import { Navbar } from "./Navbar";
import { Footer } from "./Footer";
import { getSettings, type SiteSettings } from "@/lib/queries";

export function SiteLayout({ children }: { children: React.ReactNode }) {
  const [s, setS] = useState<SiteSettings | null>(null);
  useEffect(() => { getSettings().then(setS).catch(() => {}); }, []);
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar schoolName={s?.school_name} logoUrl={s?.logo_url} />
      <main className="flex-1">{children}</main>
      {s && <Footer s={s} />}
    </div>
  );
}
