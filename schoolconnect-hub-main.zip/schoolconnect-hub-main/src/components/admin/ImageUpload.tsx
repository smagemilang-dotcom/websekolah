import { useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Upload, X, Loader2, ImageIcon } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type Props = {
  value: string | null;
  onChange: (url: string | null) => void;
  folder?: string;
  /** Max file size in MB. Default 5 */
  maxSizeMB?: number;
  /** Recommended dimensions hint shown to admin */
  hint?: string;
  /** Aspect ratio for the preview box: "square" | "video" (16:9) | "wide" (21:9) */
  aspect?: "square" | "video" | "wide";
  /** Allowed mime types. Default image/jpeg, png, webp */
  accept?: string[];
};

const DEFAULT_ACCEPT = ["image/jpeg", "image/png", "image/webp", "image/gif"];

export function ImageUpload({
  value,
  onChange,
  folder = "uploads",
  maxSizeMB = 5,
  hint,
  aspect = "square",
  accept = DEFAULT_ACCEPT,
}: Props) {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [dragOver, setDragOver] = useState(false);
  const ref = useRef<HTMLInputElement>(null);

  const aspectClass =
    aspect === "video" ? "aspect-video w-full max-w-md" :
    aspect === "wide" ? "aspect-[21/9] w-full max-w-xl" :
    "h-40 w-40";

  const validate = (file: File): string | null => {
    if (!accept.includes(file.type)) return `Format tidak didukung. Gunakan: ${accept.map((t) => t.split("/")[1]).join(", ").toUpperCase()}`;
    if (file.size > maxSizeMB * 1024 * 1024) return `Ukuran melebihi batas ${maxSizeMB}MB`;
    return null;
  };

  const handle = async (file: File) => {
    if (!file) return;
    const err = validate(file);
    if (err) { toast.error(err); return; }

    setUploading(true);
    setProgress(10);
    try {
      const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
      const path = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      setProgress(40);
      const { error } = await supabase.storage.from("site-media").upload(path, file, {
        cacheControl: "3600",
        upsert: false,
        contentType: file.type,
      });
      if (error) throw error;
      setProgress(80);
      const { data } = supabase.storage.from("site-media").getPublicUrl(path);
      onChange(data.publicUrl);
      setProgress(100);
      toast.success("Gambar berhasil diunggah");
    } catch (e: any) {
      toast.error(e.message ?? "Gagal mengunggah");
    } finally {
      setUploading(false);
      setTimeout(() => setProgress(0), 600);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handle(file);
  };

  return (
    <div className="space-y-2">
      {value ? (
        <div className="space-y-2">
          <div className={cn("relative overflow-hidden rounded-lg border bg-muted", aspectClass)}>
            <img src={value} alt="Preview" className="h-full w-full object-cover" loading="lazy" />
            <button
              type="button"
              onClick={() => onChange(null)}
              className="absolute right-2 top-2 rounded-full bg-destructive p-1.5 text-destructive-foreground shadow-md hover:opacity-90"
              aria-label="Hapus gambar"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="flex items-center gap-2">
            <Button type="button" variant="outline" size="sm" onClick={() => ref.current?.click()} disabled={uploading}>
              {uploading ? <Loader2 className="mr-2 h-3 w-3 animate-spin" /> : <Upload className="mr-2 h-3 w-3" />}
              Ganti gambar
            </Button>
            {hint && <span className="text-xs text-muted-foreground">{hint}</span>}
          </div>
        </div>
      ) : (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          onClick={() => !uploading && ref.current?.click()}
          className={cn(
            "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-6 text-center transition-colors",
            dragOver ? "border-primary bg-primary/5" : "border-border hover:border-primary/50 hover:bg-muted/50",
            aspectClass
          )}
        >
          {uploading ? (
            <>
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <div className="w-full max-w-[180px]">
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                  <div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} />
                </div>
              </div>
              <span className="text-xs text-muted-foreground">Mengunggah... {progress}%</span>
            </>
          ) : (
            <>
              <ImageIcon className="h-8 w-8 text-muted-foreground" />
              <div className="text-sm font-medium">Klik atau seret gambar ke sini</div>
              <div className="text-xs text-muted-foreground">
                {accept.map((t) => t.split("/")[1]).join(", ").toUpperCase()} · maks {maxSizeMB}MB
              </div>
              {hint && <div className="text-xs text-muted-foreground">{hint}</div>}
            </>
          )}
        </div>
      )}
      <input
        ref={ref}
        type="file"
        accept={accept.join(",")}
        className="hidden"
        onChange={(e) => e.target.files?.[0] && handle(e.target.files[0])}
      />
    </div>
  );
}
