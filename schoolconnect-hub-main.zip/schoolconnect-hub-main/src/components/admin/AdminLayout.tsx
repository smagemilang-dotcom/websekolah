import { Link, Outlet, useNavigate, useLocation } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { LayoutDashboard, Newspaper, Image, Users, Settings, MessageSquare, FileText, LogOut, GraduationCap, ShieldAlert } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type NavItem = { to: string; label: string; icon: any; exact?: boolean };
const nav: NavItem[] = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/admin/berita", label: "Berita", icon: Newspaper },
  { to: "/admin/galeri", label: "Galeri", icon: Image },
  { to: "/admin/guru", label: "Guru", icon: Users },
  { to: "/admin/testimoni", label: "Testimoni", icon: MessageSquare },
  { to: "/admin/profil", label: "Profil & PPDB", icon: FileText },
  { to: "/admin/pengaturan", label: "Pengaturan", icon: Settings },
];

export function AdminLayout() {
  const { user, isAdmin, loading } = useAuth();
  const nav2 = useNavigate();
  const loc = useLocation();

  useEffect(() => {
    if (!loading && !user) nav2({ to: "/auth" });
  }, [loading, user, nav2]);

  if (loading) return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Memuat...</div>;
  if (!user) return null;
  if (!isAdmin) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4">
        <div className="max-w-md rounded-2xl border bg-card p-8 text-center shadow-card">
          <ShieldAlert className="mx-auto h-12 w-12 text-destructive" />
          <h1 className="mt-4 text-2xl font-bold">Akses ditolak</h1>
          <p className="mt-2 text-sm text-muted-foreground">Akun Anda belum memiliki peran admin. Hubungi pengelola untuk diberikan akses.</p>
          <p className="mt-3 text-xs text-muted-foreground">Akun pertama: minta admin memberikan role <code>admin</code> di tabel <code>user_roles</code> melalui Lovable Cloud.</p>
          <button onClick={async () => { await supabase.auth.signOut(); nav2({ to: "/auth" }); }} className="mt-4 text-sm text-primary hover:underline">Keluar</button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-secondary/30">
      <aside className="hidden w-64 shrink-0 flex-col bg-sidebar text-sidebar-foreground md:flex">
        <Link to="/" className="flex h-16 items-center gap-2 border-b border-sidebar-border px-6 font-bold">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-primary"><GraduationCap className="h-4 w-4" /></div>
          Admin CMS
        </Link>
        <nav className="flex-1 space-y-1 p-3">
          {nav.map((n) => {
            const active = n.exact ? loc.pathname === n.to : loc.pathname.startsWith(n.to);
            return (
              <Link key={n.to} to={n.to as any} className={cn("flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-smooth", active ? "bg-sidebar-primary text-sidebar-primary-foreground" : "text-sidebar-foreground/80 hover:bg-sidebar-accent")}>
                <n.icon className="h-4 w-4" /> {n.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-sidebar-border p-3">
          <div className="mb-2 truncate px-3 text-xs text-sidebar-foreground/60">{user.email}</div>
          <button onClick={async () => { await supabase.auth.signOut(); toast.success("Keluar"); nav2({ to: "/" }); }} className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-sidebar-foreground/80 hover:bg-sidebar-accent">
            <LogOut className="h-4 w-4" /> Keluar
          </button>
        </div>
      </aside>
      <div className="flex-1">
        <header className="flex h-16 items-center justify-between border-b bg-background px-6 md:hidden">
          <span className="font-bold">Admin</span>
          <Link to="/" className="text-sm text-primary">Lihat Situs</Link>
        </header>
        <div className="md:hidden border-b bg-background overflow-x-auto">
          <div className="flex gap-1 p-2">
            {nav.map((n) => <Link key={n.to} to={n.to as any} className="whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium hover:bg-secondary" activeProps={{ className: "bg-primary text-primary-foreground" }} activeOptions={{ exact: n.exact }}>{n.label}</Link>)}
          </div>
        </div>
        <main className="p-6 md:p-8"><Outlet /></main>
      </div>
    </div>
  );
}
