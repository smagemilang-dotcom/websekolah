import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, Award, BookOpen, Users, GraduationCap, Calendar, Sparkles, Quote } from "lucide-react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { Button } from "@/components/ui/button";
import { getSettings, getNews, getGallery, getTeachers, getTestimonials, type SiteSettings } from "@/lib/queries";
import heroFallback from "@/assets/hero-school.jpg";

export const Route = createFileRoute("/")({ component: HomePage });

function HomePage() {
  const [s, setS] = useState<SiteSettings | null>(null);
  const [news, setNews] = useState<any[]>([]);
  const [gallery, setGallery] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [tests, setTests] = useState<any[]>([]);
  const [tIdx, setTIdx] = useState(0);

  useEffect(() => {
    getSettings().then(setS).catch(() => {});
    getNews({ limit: 3 }).then(setNews).catch(() => {});
    getGallery().then((d) => setGallery(d.slice(0, 8))).catch(() => {});
    getTeachers().then((d) => setTeachers(d.slice(0, 6))).catch(() => {});
    getTestimonials().then(setTests).catch(() => {});
  }, []);

  useEffect(() => {
    if (tests.length < 2) return;
    const i = setInterval(() => setTIdx((x) => (x + 1) % tests.length), 5000);
    return () => clearInterval(i);
  }, [tests.length]);

  const heroImg = s?.hero_image_url || heroFallback;

  return (
    <SiteLayout>
      {/* Hero */}
      <section className="relative -mt-16 min-h-[88vh] overflow-hidden bg-gradient-hero pt-16 text-white">
        <img src={heroImg} alt="" width={1920} height={1024} className="absolute inset-0 h-full w-full object-cover opacity-25 animate-fade-in-soft" />
        <div className="absolute inset-0 bg-gradient-to-b from-primary/30 via-transparent to-background/40" />
        <div className="absolute -left-32 top-20 h-96 w-96 rounded-full bg-primary-glow/20 blur-3xl animate-float-slow" />
        <div className="absolute -right-32 bottom-20 h-96 w-96 rounded-full bg-accent/20 blur-3xl animate-float-slow" style={{ animationDelay: "2s" }} />
        <div className="container relative mx-auto flex min-h-[80vh] flex-col justify-center px-4 py-20">
          <div className="max-w-3xl">
            <span className="mb-5 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-medium backdrop-blur ring-1 ring-white/20 animate-fade-up">
              <Sparkles className="h-3.5 w-3.5" /> Pendaftaran 2026/2027 telah dibuka
            </span>
            <h1 className="text-4xl font-extrabold leading-tight md:text-6xl lg:text-7xl animate-fade-up delay-100">
              {s?.hero_title ?? "Selamat Datang di SMA Nusantara"}
            </h1>
            <p className="mt-6 max-w-2xl text-lg text-white/85 md:text-xl animate-fade-up delay-200">{s?.hero_subtitle ?? s?.tagline}</p>
            <div className="mt-8 flex flex-wrap gap-3 animate-fade-up delay-300">
              <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 shadow-elegant transition-smooth hover:-translate-y-0.5">
                <Link to="/ppdb">Daftar Sekarang <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white/30 bg-white/10 text-white hover:bg-white/20 hover:text-white backdrop-blur transition-smooth">
                <Link to="/profil">Lihat Profil</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-y bg-secondary/40">
        <div className="container mx-auto grid grid-cols-2 gap-6 px-4 py-12 md:grid-cols-4">
          {[
            { icon: Users, label: "Siswa Aktif", value: s?.stat_students ?? 0 },
            { icon: GraduationCap, label: "Tenaga Pendidik", value: s?.stat_teachers ?? 0 },
            { icon: Award, label: "Prestasi", value: s?.stat_achievements ?? 0 },
            { icon: BookOpen, label: "Alumni", value: s?.stat_alumni ?? 0 },
          ].map((st, i) => (
            <div key={st.label} className="group text-center animate-fade-up" style={{ animationDelay: `${i * 100}ms` }}>
              <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-primary text-primary-foreground shadow-soft transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6"><st.icon className="h-6 w-6" /></div>
              <div className="text-3xl font-extrabold text-primary md:text-4xl">{st.value.toLocaleString("id-ID")}+</div>
              <div className="mt-1 text-sm text-muted-foreground">{st.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* About */}
      <section className="container mx-auto px-4 py-20">
        <div className="grid gap-12 md:grid-cols-2 md:items-center">
          <div>
            <span className="text-sm font-semibold uppercase tracking-wider text-primary">Tentang Sekolah</span>
            <h2 className="mt-2 text-3xl font-bold md:text-4xl">{s?.school_name ?? "SMA Nusantara"}</h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">{s?.description}</p>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl border bg-card p-5 shadow-card">
                <h3 className="mb-2 font-semibold text-primary">Visi</h3>
                <p className="text-sm text-muted-foreground">{s?.vision}</p>
              </div>
              <div className="rounded-xl border bg-card p-5 shadow-card">
                <h3 className="mb-2 font-semibold text-primary">Misi</h3>
                <p className="whitespace-pre-line text-sm text-muted-foreground">{s?.mission}</p>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="absolute -inset-4 rounded-3xl bg-gradient-primary opacity-20 blur-2xl" />
            <img src={heroImg} alt="Sekolah" loading="lazy" className="relative aspect-[4/3] w-full rounded-3xl object-cover shadow-elegant" />
          </div>
        </div>
      </section>

      {/* News */}
      <section className="bg-secondary/40 py-20">
        <div className="container mx-auto px-4">
          <div className="mb-10 flex items-end justify-between">
            <div>
              <span className="text-sm font-semibold uppercase tracking-wider text-primary">Informasi</span>
              <h2 className="mt-1 text-3xl font-bold md:text-4xl">Berita Terbaru</h2>
            </div>
            <Button asChild variant="ghost"><Link to="/berita">Semua berita <ArrowRight className="ml-1 h-4 w-4" /></Link></Button>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {news.map((n, i) => (
              <Link key={n.id} to="/berita/$slug" params={{ slug: n.slug }} className="group overflow-hidden rounded-2xl border bg-card shadow-card hover-lift animate-fade-up" style={{ animationDelay: `${i * 100}ms` }}>
                <div className="aspect-video overflow-hidden bg-muted">
                  {n.image_url ? <img src={n.image_url} alt={n.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110" /> : <div className="flex h-full items-center justify-center bg-gradient-primary text-primary-foreground"><BookOpen className="h-10 w-10 opacity-50" /></div>}
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground"><Calendar className="h-3 w-3" />{new Date(n.published_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}</div>
                  <h3 className="mt-2 line-clamp-2 font-semibold transition-colors group-hover:text-primary">{n.title}</h3>
                  <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{n.excerpt}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="container mx-auto px-4 py-20">
        <div className="mb-10 text-center">
          <span className="text-sm font-semibold uppercase tracking-wider text-primary">Galeri</span>
          <h2 className="mt-1 text-3xl font-bold md:text-4xl">Momen Sekolah</h2>
        </div>
        {gallery.length === 0 ? (
          <p className="text-center text-muted-foreground">Belum ada foto. Tambahkan dari panel admin.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {gallery.map((g, i) => (
              <div key={g.id} className="group relative aspect-square overflow-hidden rounded-2xl bg-muted shadow-card animate-fade-up" style={{ animationDelay: `${i * 60}ms` }}>
                <img src={g.image_url} alt={g.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                <div className="absolute inset-x-0 bottom-0 translate-y-2 p-3 text-xs font-medium text-white opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">{g.title}</div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Teachers */}
      <section className="bg-secondary/40 py-20">
        <div className="container mx-auto px-4">
          <div className="mb-10 text-center">
            <span className="text-sm font-semibold uppercase tracking-wider text-primary">Tim Kami</span>
            <h2 className="mt-1 text-3xl font-bold md:text-4xl">Guru & Tenaga Pendidik</h2>
          </div>
          <div className="grid grid-cols-2 gap-5 md:grid-cols-3 lg:grid-cols-6">
            {teachers.map((t, i) => (
              <div key={t.id} className="rounded-2xl bg-card p-4 text-center shadow-card hover-lift animate-fade-up" style={{ animationDelay: `${i * 80}ms` }}>
                <div className="mx-auto mb-3 flex h-20 w-20 items-center justify-center overflow-hidden rounded-full bg-gradient-primary text-primary-foreground ring-4 ring-background shadow-soft">
                  {t.photo_url ? <img src={t.photo_url} alt={t.name} className="h-full w-full object-cover transition-transform duration-500 hover:scale-110" /> : <span className="text-xl font-bold">{t.name.split(" ").map((p: string) => p[0]).slice(0, 2).join("")}</span>}
                </div>
                <div className="text-sm font-semibold">{t.name}</div>
                <div className="text-xs text-muted-foreground">{t.position}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      {tests.length > 0 && (
        <section className="container mx-auto px-4 py-20">
          <div className="mx-auto max-w-3xl text-center">
            <Quote className="mx-auto h-10 w-10 text-primary/30" />
            <div key={tIdx} className="animate-fade-in-soft">
              <p className="mt-4 text-xl font-medium leading-relaxed md:text-2xl">"{tests[tIdx].content}"</p>
              <div className="mt-6 font-semibold">{tests[tIdx].name}</div>
              <div className="text-sm text-muted-foreground">{tests[tIdx].role}</div>
            </div>
            <div className="mt-6 flex justify-center gap-1.5">
              {tests.map((_, i) => (
                <button key={i} onClick={() => setTIdx(i)} className={`h-1.5 rounded-full transition-all duration-500 ${i === tIdx ? "w-8 bg-primary" : "w-1.5 bg-border hover:bg-primary/40"}`} aria-label={`Testimoni ${i + 1}`} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="container mx-auto px-4 pb-20">
        <div className="overflow-hidden rounded-3xl bg-gradient-hero p-10 text-white shadow-elegant md:p-16">
          <div className="grid gap-6 md:grid-cols-[1fr_auto] md:items-center">
            <div>
              <h2 className="text-3xl font-bold md:text-4xl">{s?.ppdb_title ?? "Bergabunglah Bersama Kami"}</h2>
              <p className="mt-3 text-white/85">{s?.ppdb_description}</p>
              {s?.ppdb_deadline && <p className="mt-2 text-sm text-accent font-semibold">Batas pendaftaran: {s.ppdb_deadline}</p>}
            </div>
            <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
              <Link to="/ppdb">Daftar PPDB <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
