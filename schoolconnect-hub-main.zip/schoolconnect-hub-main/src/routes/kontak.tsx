import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { getSettings, type SiteSettings } from "@/lib/queries";
import { MapPin, Phone, Mail } from "lucide-react";

export const Route = createFileRoute("/kontak")({
  head: () => ({ meta: [{ title: "Kontak — SMA Nusantara" }, { name: "description", content: "Hubungi SMA Nusantara." }] }),
  component: KontakPage,
});

function KontakPage() {
  const [s, setS] = useState<SiteSettings | null>(null);
  useEffect(() => { getSettings().then(setS).catch(() => {}); }, []);
  return (
    <SiteLayout>
      <section className="bg-gradient-hero py-16 text-white">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-extrabold md:text-5xl">Hubungi Kami</h1>
          <p className="mt-3 text-white/85">Kami siap menjawab pertanyaan Anda</p>
        </div>
      </section>
      <section className="container mx-auto grid gap-10 px-4 py-16 md:grid-cols-2">
        <div className="space-y-6">
          {[{icon: MapPin, label: "Alamat", value: s?.address}, {icon: Phone, label: "Telepon", value: s?.phone}, {icon: Mail, label: "Email", value: s?.email}].map((it) => (
            <div key={it.label} className="flex gap-4 rounded-xl border bg-card p-5 shadow-card">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-primary text-primary-foreground"><it.icon className="h-5 w-5" /></div>
              <div>
                <div className="text-sm font-semibold text-muted-foreground">{it.label}</div>
                <div className="font-medium">{it.value}</div>
              </div>
            </div>
          ))}
        </div>
        {s?.maps_embed_url && (
          <div className="overflow-hidden rounded-2xl border shadow-card">
            <iframe src={s.maps_embed_url} title="Lokasi sekolah" loading="lazy" className="h-full min-h-[400px] w-full" />
          </div>
        )}
      </section>
    </SiteLayout>
  );
}
