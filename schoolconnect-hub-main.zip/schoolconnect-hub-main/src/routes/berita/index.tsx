import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { getNews } from "@/lib/queries";
import { Calendar, Search, BookOpen } from "lucide-react";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/berita/")({
  head: () => ({ meta: [{ title: "Berita — SMA Nusantara" }, { name: "description", content: "Berita dan informasi terbaru SMA Nusantara." }] }),
  component: BeritaList,
});

const PAGE = 9;

function BeritaList() {
  const [items, setItems] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);

  useEffect(() => {
    const t = setTimeout(() => {
      getNews({ search }).then((d) => { setItems(d); setPage(1); }).catch(() => {});
    }, 250);
    return () => clearTimeout(t);
  }, [search]);

  const total = Math.ceil(items.length / PAGE) || 1;
  const slice = items.slice((page - 1) * PAGE, page * PAGE);

  return (
    <SiteLayout>
      <section className="bg-gradient-hero py-16 text-white">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-extrabold md:text-5xl">Berita Sekolah</h1>
          <p className="mt-3 text-white/85">Informasi dan kegiatan terbaru</p>
        </div>
      </section>
      <section className="container mx-auto px-4 py-12">
        <div className="relative mb-8 max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Cari berita..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
        </div>
        {slice.length === 0 ? (
          <p className="text-muted-foreground">Tidak ada berita.</p>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {slice.map((n) => (
              <Link key={n.id} to="/berita/$slug" params={{ slug: n.slug }} className="group overflow-hidden rounded-xl border bg-card shadow-card transition-smooth hover:shadow-elegant">
                <div className="aspect-video overflow-hidden bg-muted">
                  {n.image_url ? <img src={n.image_url} alt={n.title} loading="lazy" className="h-full w-full object-cover transition-smooth group-hover:scale-105" /> : <div className="flex h-full items-center justify-center bg-gradient-primary text-primary-foreground"><BookOpen className="h-10 w-10 opacity-50" /></div>}
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground"><Calendar className="h-3 w-3" />{new Date(n.published_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}</div>
                  <h3 className="mt-2 line-clamp-2 font-semibold group-hover:text-primary">{n.title}</h3>
                  <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">{n.excerpt}</p>
                </div>
              </Link>
            ))}
          </div>
        )}
        {total > 1 && (
          <div className="mt-10 flex justify-center gap-2">
            {Array.from({ length: total }).map((_, i) => (
              <button key={i} onClick={() => setPage(i + 1)} className={`h-9 min-w-9 rounded-md px-3 text-sm font-medium ${page === i + 1 ? "bg-primary text-primary-foreground" : "border bg-card hover:bg-secondary"}`}>{i + 1}</button>
            ))}
          </div>
        )}
      </section>
    </SiteLayout>
  );
}
