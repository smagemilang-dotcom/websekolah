import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { getNewsBySlug } from "@/lib/queries";
import { Calendar, ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/berita/$slug")({ component: BeritaDetail });

function BeritaDetail() {
  const { slug } = Route.useParams();
  const [n, setN] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => { getNewsBySlug(slug).then((d) => { setN(d); setLoading(false); }); }, [slug]);

  if (loading) return <SiteLayout><div className="container mx-auto px-4 py-20 text-center text-muted-foreground">Memuat...</div></SiteLayout>;
  if (!n) return <SiteLayout><div className="container mx-auto px-4 py-20 text-center"><h1 className="text-2xl font-bold">Berita tidak ditemukan</h1><Link to="/berita" className="mt-4 inline-block text-primary">Kembali</Link></div></SiteLayout>;

  return (
    <SiteLayout>
      <article className="container mx-auto max-w-3xl px-4 py-12">
        <Link to="/berita" className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary"><ArrowLeft className="h-4 w-4" /> Kembali ke berita</Link>
        <h1 className="text-3xl font-extrabold md:text-4xl">{n.title}</h1>
        <div className="mt-3 flex items-center gap-2 text-sm text-muted-foreground"><Calendar className="h-4 w-4" />{new Date(n.published_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}</div>
        {n.image_url && <img src={n.image_url} alt={n.title} className="mt-6 aspect-video w-full rounded-2xl object-cover shadow-card" />}
        <div className="prose prose-lg mt-8 max-w-none whitespace-pre-line text-foreground/90 leading-relaxed">{n.content}</div>
      </article>
    </SiteLayout>
  );
}
