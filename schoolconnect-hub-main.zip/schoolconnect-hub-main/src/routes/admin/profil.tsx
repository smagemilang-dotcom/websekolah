import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { ImageUpload } from "@/components/admin/ImageUpload";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/profil")({ component: ProfilAdmin });

function ProfilAdmin() {
  const [s, setS] = useState<any>(null);
  useEffect(() => { supabase.from("site_settings").select("*").eq("id", 1).single().then(({ data }) => setS(data)); }, []);
  if (!s) return <div className="text-muted-foreground">Memuat...</div>;
  const set = (k: string, v: any) => setS({ ...s, [k]: v });
  const save = async () => {
    const { error } = await supabase.from("site_settings").update(s).eq("id", 1);
    if (error) return toast.error(error.message);
    toast.success("Disimpan");
  };

  return (
    <div className="max-w-3xl">
      <h1 className="text-3xl font-bold">Profil Sekolah & PPDB</h1>
      <p className="text-muted-foreground">Kelola konten profil dan informasi PPDB</p>
      <div className="mt-6 space-y-8">
        <section className="rounded-2xl border bg-card p-6 shadow-card space-y-4">
          <h2 className="font-semibold">Hero & Profil</h2>
          <div><Label>Judul Hero</Label><Input value={s.hero_title ?? ""} onChange={(e) => set("hero_title", e.target.value)} /></div>
          <div><Label>Subjudul Hero</Label><Input value={s.hero_subtitle ?? ""} onChange={(e) => set("hero_subtitle", e.target.value)} /></div>
          <div><Label>Gambar Hero / Banner</Label><ImageUpload folder="hero" value={s.hero_image_url} onChange={(url) => set("hero_image_url", url)} aspect="wide" maxSizeMB={5} hint="Rekomendasi: 1920×800px, JPG/WebP" /></div>
          <div><Label>Deskripsi Sekolah</Label><Textarea rows={4} value={s.description ?? ""} onChange={(e) => set("description", e.target.value)} /></div>
          <div><Label>Visi</Label><Textarea rows={3} value={s.vision ?? ""} onChange={(e) => set("vision", e.target.value)} /></div>
          <div><Label>Misi (gunakan baris baru)</Label><Textarea rows={5} value={s.mission ?? ""} onChange={(e) => set("mission", e.target.value)} /></div>
        </section>

        <section className="rounded-2xl border bg-card p-6 shadow-card space-y-4">
          <h2 className="font-semibold">Statistik</h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            <div><Label>Siswa</Label><Input type="number" value={s.stat_students} onChange={(e) => set("stat_students", +e.target.value)} /></div>
            <div><Label>Guru</Label><Input type="number" value={s.stat_teachers} onChange={(e) => set("stat_teachers", +e.target.value)} /></div>
            <div><Label>Prestasi</Label><Input type="number" value={s.stat_achievements} onChange={(e) => set("stat_achievements", +e.target.value)} /></div>
            <div><Label>Alumni</Label><Input type="number" value={s.stat_alumni} onChange={(e) => set("stat_alumni", +e.target.value)} /></div>
          </div>
        </section>

        <section className="rounded-2xl border bg-card p-6 shadow-card space-y-4">
          <h2 className="font-semibold">PPDB</h2>
          <div className="flex items-center gap-2"><Switch checked={s.ppdb_open} onCheckedChange={(v) => set("ppdb_open", v)} /><Label>Pendaftaran Dibuka</Label></div>
          <div><Label>Judul</Label><Input value={s.ppdb_title ?? ""} onChange={(e) => set("ppdb_title", e.target.value)} /></div>
          <div><Label>Deskripsi</Label><Textarea rows={3} value={s.ppdb_description ?? ""} onChange={(e) => set("ppdb_description", e.target.value)} /></div>
          <div><Label>Link Pendaftaran</Label><Input value={s.ppdb_url ?? ""} onChange={(e) => set("ppdb_url", e.target.value)} /></div>
          <div><Label>Batas Pendaftaran</Label><Input value={s.ppdb_deadline ?? ""} onChange={(e) => set("ppdb_deadline", e.target.value)} /></div>
        </section>

        <Button onClick={save} size="lg">Simpan Perubahan</Button>
      </div>
    </div>
  );
}
