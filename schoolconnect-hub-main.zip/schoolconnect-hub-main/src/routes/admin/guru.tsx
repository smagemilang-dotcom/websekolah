import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ImageUpload } from "@/components/admin/ImageUpload";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/guru")({ component: GuruAdmin });

const empty = { id: "", name: "", position: "", subject: "", photo_url: null as string | null, sort_order: 0 };

function GuruAdmin() {
  const [items, setItems] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const load = () => supabase.from("teachers").select("*").order("sort_order").then(({ data }) => setItems(data ?? []));
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!form.name || !form.position) { toast.error("Nama & jabatan wajib"); return; }
    const payload = { name: form.name, position: form.position, subject: form.subject, photo_url: form.photo_url, sort_order: form.sort_order };
    const { error } = form.id ? await supabase.from("teachers").update(payload).eq("id", form.id) : await supabase.from("teachers").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Tersimpan"); setOpen(false); setForm(empty); load();
  };
  const del = async (id: string) => { if (!confirm("Hapus guru?")) return; await supabase.from("teachers").delete().eq("id", id); load(); };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div><h1 className="text-3xl font-bold">Guru</h1><p className="text-muted-foreground">Kelola data guru</p></div>
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setForm(empty); }}>
          <DialogTrigger asChild><Button onClick={() => setForm(empty)}><Plus className="mr-1 h-4 w-4" />Tambah Guru</Button></DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>{form.id ? "Edit" : "Tambah"} Guru</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div><Label>Nama</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><Label>Jabatan</Label><Input value={form.position} onChange={(e) => setForm({ ...form, position: e.target.value })} /></div>
              <div><Label>Mata Pelajaran</Label><Input value={form.subject ?? ""} onChange={(e) => setForm({ ...form, subject: e.target.value })} /></div>
              <div><Label>Urutan</Label><Input type="number" value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: +e.target.value })} /></div>
              <div><Label>Foto</Label><ImageUpload folder="teachers" value={form.photo_url} onChange={(url) => setForm({ ...form, photo_url: url })} /></div>
              <Button onClick={save} className="w-full">Simpan</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      <div className="mt-6 overflow-hidden rounded-xl border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-left"><tr><th className="p-3">Foto</th><th className="p-3">Nama</th><th className="p-3">Jabatan</th><th className="p-3">Mapel</th><th className="p-3"></th></tr></thead>
          <tbody>
            {items.map((t) => (
              <tr key={t.id} className="border-t">
                <td className="p-3">{t.photo_url ? <img src={t.photo_url} className="h-10 w-10 rounded-full object-cover" alt="" /> : <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary text-xs">{t.name[0]}</div>}</td>
                <td className="p-3 font-medium">{t.name}</td>
                <td className="p-3">{t.position}</td>
                <td className="p-3 text-muted-foreground">{t.subject}</td>
                <td className="p-3 text-right">
                  <Button size="icon" variant="ghost" onClick={() => { setForm({ id: t.id, name: t.name, position: t.position, subject: t.subject ?? "", photo_url: t.photo_url, sort_order: t.sort_order }); setOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => del(t.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </td>
              </tr>
            ))}
            {items.length === 0 && <tr><td colSpan={5} className="p-6 text-center text-muted-foreground">Belum ada data</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
