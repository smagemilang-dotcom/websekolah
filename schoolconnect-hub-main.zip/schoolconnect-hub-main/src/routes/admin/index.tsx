import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Newspaper, Image, Users, MessageSquare } from "lucide-react";

export const Route = createFileRoute("/admin/")({ component: Dashboard });

function Dashboard() {
  const [stats, setStats] = useState({ news: 0, gallery: 0, teachers: 0, testimonials: 0 });
  useEffect(() => {
    (async () => {
      const [n, g, t, te] = await Promise.all([
        supabase.from("news").select("*", { count: "exact", head: true }),
        supabase.from("gallery").select("*", { count: "exact", head: true }),
        supabase.from("teachers").select("*", { count: "exact", head: true }),
        supabase.from("testimonials").select("*", { count: "exact", head: true }),
      ]);
      setStats({ news: n.count ?? 0, gallery: g.count ?? 0, teachers: t.count ?? 0, testimonials: te.count ?? 0 });
    })();
  }, []);

  const cards = [
    { icon: Newspaper, label: "Berita", value: stats.news, color: "from-blue-500 to-blue-600" },
    { icon: Image, label: "Galeri", value: stats.gallery, color: "from-emerald-500 to-emerald-600" },
    { icon: Users, label: "Guru", value: stats.teachers, color: "from-amber-500 to-amber-600" },
    { icon: MessageSquare, label: "Testimoni", value: stats.testimonials, color: "from-purple-500 to-purple-600" },
  ];

  return (
    <div>
      <h1 className="text-3xl font-bold">Dashboard</h1>
      <p className="mt-1 text-muted-foreground">Ringkasan konten website sekolah</p>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="rounded-2xl border bg-card p-6 shadow-card">
            <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${c.color} text-white`}><c.icon className="h-6 w-6" /></div>
            <div className="text-3xl font-bold">{c.value}</div>
            <div className="text-sm text-muted-foreground">{c.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
