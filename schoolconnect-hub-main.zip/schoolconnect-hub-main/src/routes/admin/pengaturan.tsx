import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ImageUpload } from "@/components/admin/ImageUpload";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/pengaturan")({ component: PengaturanAdmin });

function PengaturanAdmin() {
  const [s, setS] = useState<any>(null);
  useEffect(() => { supabase.from("site_settings").select("*").eq("id", 1).single().then(({ data }) => setS(data)); }, []);
  if (!s) return <div className="text-muted-foreground">Memuat...</div>;
  const set = (k: string, v: any) => setS({ ...s, [k]: v });
  const save = async () => {
    const { error } = await supabase.from("site_settings").update(s).eq("id", 1);
    if (error) return toast.error(error.message);
    toast.success("Disimpan");
  };

  return (
    <div className="max-w-3xl">
      <h1 className="text-3xl font-bold">Pengaturan Website</h1>
      <p className="text-muted-foreground">Identitas, kontak, dan media sosial</p>
      <div className="mt-6 space-y-8">
        <section className="rounded-2xl border bg-card p-6 shadow-card space-y-4">
          <h2 className="font-semibold">Identitas</h2>
          <div><Label>Nama Sekolah</Label><Input value={s.school_name} onChange={(e) => set("school_name", e.target.value)} /></div>
          <div><Label>Tagline</Label><Input value={s.tagline} onChange={(e) => set("tagline", e.target.value)} /></div>
          <div><Label>Logo Sekolah</Label><ImageUpload folder="logo" value={s.logo_url} onChange={(url) => set("logo_url", url)} aspect="square" maxSizeMB={2} hint="Rekomendasi: 512×512px, PNG transparan" accept={["image/png", "image/webp", "image/svg+xml"]} /></div>
        </section>

        <section className="rounded-2xl border bg-card p-6 shadow-card space-y-4">
          <h2 className="font-semibold">Kontak</h2>
          <div><Label>Alamat</Label><Textarea rows={2} value={s.address ?? ""} onChange={(e) => set("address", e.target.value)} /></div>
          <div className="grid gap-4 md:grid-cols-2">
            <div><Label>Telepon</Label><Input value={s.phone ?? ""} onChange={(e) => set("phone", e.target.value)} /></div>
            <div><Label>Email</Label><Input type="email" value={s.email ?? ""} onChange={(e) => set("email", e.target.value)} /></div>
          </div>
          <div><Label>Embed Google Maps URL</Label><Textarea rows={2} value={s.maps_embed_url ?? ""} onChange={(e) => set("maps_embed_url", e.target.value)} /></div>
        </section>

        <section className="rounded-2xl border bg-card p-6 shadow-card space-y-4">
          <h2 className="font-semibold">Sosial Media</h2>
          <div><Label>Facebook URL</Label><Input value={s.facebook_url ?? ""} onChange={(e) => set("facebook_url", e.target.value)} /></div>
          <div><Label>Instagram URL</Label><Input value={s.instagram_url ?? ""} onChange={(e) => set("instagram_url", e.target.value)} /></div>
          <div><Label>YouTube URL</Label><Input value={s.youtube_url ?? ""} onChange={(e) => set("youtube_url", e.target.value)} /></div>
        </section>

        <Button onClick={save} size="lg">Simpan Perubahan</Button>
      </div>
    </div>
  );
}
