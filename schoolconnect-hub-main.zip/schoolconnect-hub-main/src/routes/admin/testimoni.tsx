import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ImageUpload } from "@/components/admin/ImageUpload";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/testimoni")({ component: TestimoniAdmin });

const empty = { id: "", name: "", role: "", content: "", photo_url: null as string | null, sort_order: 0 };

function TestimoniAdmin() {
  const [items, setItems] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const load = () => supabase.from("testimonials").select("*").order("sort_order").then(({ data }) => setItems(data ?? []));
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!form.name || !form.content) { toast.error("Nama & isi wajib"); return; }
    const payload = { name: form.name, role: form.role, content: form.content, photo_url: form.photo_url, sort_order: form.sort_order };
    const { error } = form.id ? await supabase.from("testimonials").update(payload).eq("id", form.id) : await supabase.from("testimonials").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Tersimpan"); setOpen(false); setForm(empty); load();
  };
  const del = async (id: string) => { if (!confirm("Hapus?")) return; await supabase.from("testimonials").delete().eq("id", id); load(); };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div><h1 className="text-3xl font-bold">Testimoni</h1><p className="text-muted-foreground">Kelola testimoni</p></div>
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setForm(empty); }}>
          <DialogTrigger asChild><Button onClick={() => setForm(empty)}><Plus className="mr-1 h-4 w-4" />Tambah</Button></DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>{form.id ? "Edit" : "Tambah"} Testimoni</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div><Label>Nama</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><Label>Peran</Label><Input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} placeholder="Alumni 2023 / Orang Tua / Siswa" /></div>
              <div><Label>Isi Testimoni</Label><Textarea rows={4} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} /></div>
              <div><Label>Urutan</Label><Input type="number" value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: +e.target.value })} /></div>
              <div><Label>Foto</Label><ImageUpload folder="testimonials" value={form.photo_url} onChange={(url) => setForm({ ...form, photo_url: url })} /></div>
              <Button onClick={save} className="w-full">Simpan</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {items.map((t) => (
          <div key={t.id} className="rounded-xl border bg-card p-5 shadow-card">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="font-semibold">{t.name}</div>
                <div className="text-xs text-muted-foreground">{t.role}</div>
              </div>
              <div className="flex gap-1">
                <Button size="icon" variant="ghost" onClick={() => { setForm({ id: t.id, name: t.name, role: t.role, content: t.content, photo_url: t.photo_url, sort_order: t.sort_order }); setOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                <Button size="icon" variant="ghost" onClick={() => del(t.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">"{t.content}"</p>
          </div>
        ))}
        {items.length === 0 && <div className="col-span-full rounded-xl border border-dashed p-12 text-center text-muted-foreground">Belum ada testimoni</div>}
      </div>
    </div>
  );
}
