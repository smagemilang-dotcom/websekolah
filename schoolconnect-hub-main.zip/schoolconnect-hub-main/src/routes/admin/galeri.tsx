import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ImageUpload } from "@/components/admin/ImageUpload";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/galeri")({ component: GaleriAdmin });

const empty = { id: "", title: "", caption: "", image_url: null as string | null, sort_order: 0 };

function GaleriAdmin() {
  const [items, setItems] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const load = () => supabase.from("gallery").select("*").order("sort_order").then(({ data }) => setItems(data ?? []));
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!form.title || !form.image_url) { toast.error("Judul & gambar wajib"); return; }
    const payload = { title: form.title, caption: form.caption, image_url: form.image_url, sort_order: form.sort_order };
    const { error } = form.id ? await supabase.from("gallery").update(payload).eq("id", form.id) : await supabase.from("gallery").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Tersimpan"); setOpen(false); setForm(empty); load();
  };
  const del = async (id: string) => { if (!confirm("Hapus foto?")) return; const { error } = await supabase.from("gallery").delete().eq("id", id); if (error) return toast.error(error.message); load(); };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div><h1 className="text-3xl font-bold">Galeri</h1><p className="text-muted-foreground">Kelola foto galeri</p></div>
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setForm(empty); }}>
          <DialogTrigger asChild><Button onClick={() => setForm(empty)}><Plus className="mr-1 h-4 w-4" />Tambah Foto</Button></DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>{form.id ? "Edit" : "Tambah"} Foto</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div><Label>Judul</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
              <div><Label>Keterangan</Label><Textarea rows={2} value={form.caption ?? ""} onChange={(e) => setForm({ ...form, caption: e.target.value })} /></div>
              <div><Label>Urutan</Label><Input type="number" value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: +e.target.value })} /></div>
              <div><Label>Gambar</Label><ImageUpload folder="gallery" value={form.image_url} onChange={(url) => setForm({ ...form, image_url: url })} aspect="square" maxSizeMB={5} hint="Rekomendasi: 1200×1200px" /></div>
              <Button onClick={save} className="w-full">Simpan</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {items.map((g) => (
          <div key={g.id} className="group relative aspect-square overflow-hidden rounded-xl border bg-card">
            <img src={g.image_url} alt={g.title} className="h-full w-full object-cover" />
            <div className="absolute inset-x-0 bottom-0 bg-black/70 p-2 text-white">
              <div className="truncate text-xs font-medium">{g.title}</div>
            </div>
            <div className="absolute right-1 top-1 flex gap-1 opacity-0 transition-smooth group-hover:opacity-100">
              <Button size="icon" variant="secondary" className="h-7 w-7" onClick={() => { setForm({ id: g.id, title: g.title, caption: g.caption ?? "", image_url: g.image_url, sort_order: g.sort_order }); setOpen(true); }}><Pencil className="h-3 w-3" /></Button>
              <Button size="icon" variant="destructive" className="h-7 w-7" onClick={() => del(g.id)}><Trash2 className="h-3 w-3" /></Button>
            </div>
          </div>
        ))}
        {items.length === 0 && <div className="col-span-full rounded-xl border border-dashed p-12 text-center text-muted-foreground">Belum ada foto</div>}
      </div>
    </div>
  );
}
