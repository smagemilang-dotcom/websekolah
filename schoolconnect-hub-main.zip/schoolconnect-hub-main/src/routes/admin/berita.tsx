import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ImageUpload } from "@/components/admin/ImageUpload";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/berita")({ component: BeritaAdmin });

const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80);
const empty = { id: "", title: "", slug: "", excerpt: "", content: "", image_url: null as string | null, published: true };

function BeritaAdmin() {
  const [items, setItems] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);

  const load = () => supabase.from("news").select("*").order("created_at", { ascending: false }).then(({ data }) => setItems(data ?? []));
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!form.title || !form.content) { toast.error("Judul dan konten wajib"); return; }
    const slug = form.slug || slugify(form.title);
    const payload = { title: form.title, slug, excerpt: form.excerpt, content: form.content, image_url: form.image_url, published: form.published };
    const { error } = form.id
      ? await supabase.from("news").update(payload).eq("id", form.id)
      : await supabase.from("news").insert(payload);
    if (error) return toast.error(error.message);
    toast.success("Tersimpan"); setOpen(false); setForm(empty); load();
  };
  const del = async (id: string) => { if (!confirm("Hapus berita ini?")) return; const { error } = await supabase.from("news").delete().eq("id", id); if (error) return toast.error(error.message); toast.success("Dihapus"); load(); };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div><h1 className="text-3xl font-bold">Berita</h1><p className="text-muted-foreground">Kelola berita sekolah</p></div>
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setForm(empty); }}>
          <DialogTrigger asChild><Button onClick={() => setForm(empty)}><Plus className="mr-1 h-4 w-4" />Tambah</Button></DialogTrigger>
          <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
            <DialogHeader><DialogTitle>{form.id ? "Edit" : "Tambah"} Berita</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div><Label>Judul</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value, slug: form.id ? form.slug : slugify(e.target.value) })} /></div>
              <div><Label>Slug</Label><Input value={form.slug} onChange={(e) => setForm({ ...form, slug: slugify(e.target.value) })} /></div>
              <div><Label>Ringkasan</Label><Textarea rows={2} value={form.excerpt ?? ""} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} /></div>
              <div><Label>Konten</Label><Textarea rows={8} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} /></div>
              <div><Label>Gambar</Label><ImageUpload folder="news" value={form.image_url} onChange={(url) => setForm({ ...form, image_url: url })} /></div>
              <div className="flex items-center gap-2"><Switch checked={form.published} onCheckedChange={(v) => setForm({ ...form, published: v })} /><Label>Terbitkan</Label></div>
              <Button onClick={save} className="w-full">Simpan</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      <div className="mt-6 overflow-hidden rounded-xl border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-left"><tr><th className="p-3">Judul</th><th className="p-3">Status</th><th className="p-3">Tanggal</th><th className="p-3"></th></tr></thead>
          <tbody>
            {items.map((n) => (
              <tr key={n.id} className="border-t">
                <td className="p-3 font-medium">{n.title}</td>
                <td className="p-3"><span className={`rounded-full px-2 py-0.5 text-xs ${n.published ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>{n.published ? "Terbit" : "Draft"}</span></td>
                <td className="p-3 text-muted-foreground">{new Date(n.published_at).toLocaleDateString("id-ID")}</td>
                <td className="p-3 text-right">
                  <Button size="icon" variant="ghost" onClick={() => { setForm({ id: n.id, title: n.title, slug: n.slug, excerpt: n.excerpt ?? "", content: n.content, image_url: n.image_url, published: n.published }); setOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => del(n.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </td>
              </tr>
            ))}
            {items.length === 0 && <tr><td colSpan={4} className="p-6 text-center text-muted-foreground">Belum ada berita</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
