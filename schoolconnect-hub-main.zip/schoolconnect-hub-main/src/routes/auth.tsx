import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GraduationCap } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "Login Admin — SMA Nusantara" }] }),
  component: AuthPage,
});

const schema = z.object({ email: z.string().email("Email tidak valid"), password: z.string().min(6, "Min. 6 karakter") });

function AuthPage() {
  const nav = useNavigate();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse({ email, password });
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/admin` } });
        if (error) throw error;
        toast.success("Akun dibuat! Silakan login.");
        setMode("login");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Berhasil masuk");
        nav({ to: "/admin" });
      }
    } catch (e: any) {
      toast.error(e.message ?? "Terjadi kesalahan");
    } finally { setLoading(false); }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-hero px-4">
      <div className="w-full max-w-md rounded-2xl bg-card p-8 shadow-elegant">
        <Link to="/" className="mb-6 flex items-center gap-2 font-bold">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-gradient-primary text-primary-foreground"><GraduationCap className="h-5 w-5" /></div>
          SMA Nusantara
        </Link>
        <h1 className="text-2xl font-bold">{mode === "login" ? "Masuk Admin" : "Daftar Akun"}</h1>
        <p className="mt-1 text-sm text-muted-foreground">Akses panel pengelolaan konten sekolah</p>
        <form onSubmit={onSubmit} className="mt-6 space-y-4">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div>
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>{loading ? "Memproses..." : mode === "login" ? "Masuk" : "Daftar"}</Button>
        </form>
        <button onClick={() => setMode(mode === "login" ? "signup" : "login")} className="mt-4 w-full text-center text-sm text-primary hover:underline">
          {mode === "login" ? "Belum punya akun? Daftar" : "Sudah punya akun? Masuk"}
        </button>
        <Link to="/" className="mt-2 block text-center text-xs text-muted-foreground hover:text-primary">← Kembali ke beranda</Link>
      </div>
    </div>
  );
}
