import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { getSettings, type SiteSettings } from "@/lib/queries";
import { Target, Eye } from "lucide-react";

export const Route = createFileRoute("/profil")({
  head: () => ({ meta: [{ title: "Profil Sekolah — SMA Nusantara" }, { name: "description", content: "Profil, visi, dan misi SMA Nusantara." }] }),
  component: ProfilPage,
});

function ProfilPage() {
  const [s, setS] = useState<SiteSettings | null>(null);
  useEffect(() => { getSettings().then(setS).catch(() => {}); }, []);
  return (
    <SiteLayout>
      <section className="bg-gradient-hero py-20 text-white">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-extrabold md:text-5xl">Profil Sekolah</h1>
          <p className="mt-3 max-w-2xl text-white/85">Mengenal lebih dekat {s?.school_name}</p>
        </div>
      </section>
      <section className="container mx-auto max-w-4xl px-4 py-16">
        <p className="text-lg leading-relaxed text-foreground/90">{s?.description}</p>
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          <div className="rounded-2xl border bg-card p-8 shadow-card">
            <Eye className="mb-4 h-8 w-8 text-primary" />
            <h2 className="mb-3 text-2xl font-bold">Visi</h2>
            <p className="text-muted-foreground leading-relaxed">{s?.vision}</p>
          </div>
          <div className="rounded-2xl border bg-card p-8 shadow-card">
            <Target className="mb-4 h-8 w-8 text-primary" />
            <h2 className="mb-3 text-2xl font-bold">Misi</h2>
            <p className="whitespace-pre-line text-muted-foreground leading-relaxed">{s?.mission}</p>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
