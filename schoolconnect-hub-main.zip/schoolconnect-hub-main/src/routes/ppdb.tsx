import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { getSettings, type SiteSettings } from "@/lib/queries";
import { Button } from "@/components/ui/button";
import { Calendar, CheckCircle2, AlertCircle } from "lucide-react";

export const Route = createFileRoute("/ppdb")({
  head: () => ({ meta: [{ title: "PPDB — SMA Nusantara" }, { name: "description", content: "Informasi Penerimaan Peserta Didik Baru SMA Nusantara." }] }),
  component: PpdbPage,
});

function PpdbPage() {
  const [s, setS] = useState<SiteSettings | null>(null);
  useEffect(() => { getSettings().then(setS).catch(() => {}); }, []);
  return (
    <SiteLayout>
      <section className="bg-gradient-hero py-20 text-white">
        <div className="container mx-auto max-w-3xl px-4 text-center">
          <span className={`mb-4 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium ${s?.ppdb_open ? "bg-accent text-accent-foreground" : "bg-destructive"}`}>
            {s?.ppdb_open ? <><CheckCircle2 className="h-3.5 w-3.5" /> Pendaftaran Dibuka</> : <><AlertCircle className="h-3.5 w-3.5" /> Pendaftaran Ditutup</>}
          </span>
          <h1 className="text-4xl font-extrabold md:text-5xl">{s?.ppdb_title}</h1>
          <p className="mt-4 text-white/85">{s?.ppdb_description}</p>
          {s?.ppdb_deadline && (
            <div className="mt-6 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm backdrop-blur">
              <Calendar className="h-4 w-4" /> Batas pendaftaran: <span className="font-semibold">{s.ppdb_deadline}</span>
            </div>
          )}
          {s?.ppdb_open && s?.ppdb_url && (
            <div className="mt-8">
              <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 shadow-elegant">
                <a href={s.ppdb_url} target="_blank" rel="noreferrer">Daftar Sekarang</a>
              </Button>
            </div>
          )}
        </div>
      </section>
      <section className="container mx-auto max-w-3xl px-4 py-16">
        <h2 className="text-2xl font-bold">Persyaratan Pendaftaran</h2>
        <ul className="mt-6 space-y-3 text-muted-foreground">
          {["Fotokopi ijazah/SKL SMP yang sudah dilegalisir", "Fotokopi rapor SMP semester 1–6", "Akta kelahiran", "Kartu Keluarga", "Pas foto terbaru ukuran 3x4 (4 lembar)", "Mengisi formulir pendaftaran"].map((r) => (
            <li key={r} className="flex gap-3"><CheckCircle2 className="h-5 w-5 shrink-0 text-primary" />{r}</li>
          ))}
        </ul>
      </section>
    </SiteLayout>
  );
}
