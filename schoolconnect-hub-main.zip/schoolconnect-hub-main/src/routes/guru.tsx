import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { getTeachers } from "@/lib/queries";

export const Route = createFileRoute("/guru")({
  head: () => ({ meta: [{ title: "Guru — SMA Nusantara" }, { name: "description", content: "Tenaga pendidik SMA Nusantara." }] }),
  component: GuruPage,
});

function GuruPage() {
  const [items, setItems] = useState<any[]>([]);
  useEffect(() => { getTeachers().then(setItems).catch(() => {}); }, []);
  return (
    <SiteLayout>
      <section className="bg-gradient-hero py-16 text-white">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-extrabold md:text-5xl">Guru & Tenaga Pendidik</h1>
          <p className="mt-3 text-white/85">Para pendidik berdedikasi</p>
        </div>
      </section>
      <section className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-2 gap-5 md:grid-cols-3 lg:grid-cols-4">
          {items.map((t) => (
            <div key={t.id} className="rounded-2xl border bg-card p-6 text-center shadow-card transition-smooth hover:shadow-elegant">
              <div className="mx-auto mb-4 flex h-24 w-24 items-center justify-center overflow-hidden rounded-full bg-gradient-primary text-primary-foreground">
                {t.photo_url ? <img src={t.photo_url} alt={t.name} className="h-full w-full object-cover" /> : <span className="text-2xl font-bold">{t.name.split(" ").map((p: string) => p[0]).slice(0, 2).join("")}</span>}
              </div>
              <div className="font-semibold">{t.name}</div>
              <div className="text-sm text-primary">{t.position}</div>
              {t.subject && <div className="mt-1 text-xs text-muted-foreground">{t.subject}</div>}
            </div>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
