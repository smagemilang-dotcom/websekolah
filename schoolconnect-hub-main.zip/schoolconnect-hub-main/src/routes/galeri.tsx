import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { getGallery } from "@/lib/queries";

export const Route = createFileRoute("/galeri")({
  head: () => ({ meta: [{ title: "Galeri — SMA Nusantara" }, { name: "description", content: "Galeri foto kegiatan SMA Nusantara." }] }),
  component: GaleriPage,
});

function GaleriPage() {
  const [items, setItems] = useState<any[]>([]);
  useEffect(() => { getGallery().then(setItems).catch(() => {}); }, []);
  return (
    <SiteLayout>
      <section className="bg-gradient-hero py-16 text-white">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-extrabold md:text-5xl">Galeri</h1>
          <p className="mt-3 text-white/85">Momen kegiatan sekolah</p>
        </div>
      </section>
      <section className="container mx-auto px-4 py-12">
        {items.length === 0 ? <p className="text-center text-muted-foreground">Belum ada foto.</p> : (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {items.map((g) => (
              <div key={g.id} className="group relative aspect-square overflow-hidden rounded-xl bg-muted shadow-card">
                <img src={g.image_url} alt={g.title} loading="lazy" className="h-full w-full object-cover transition-smooth group-hover:scale-110" />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-3 text-sm text-white opacity-0 transition-smooth group-hover:opacity-100">
                  <div className="font-semibold">{g.title}</div>
                  {g.caption && <div className="text-xs text-white/80">{g.caption}</div>}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </SiteLayout>
  );
}
